package com.xitech.mp3.interfaces;

import androidx.annotation.ColorInt;

public interface PaletteColorHolder {

    @ColorInt
    int getPaletteColor();
}
