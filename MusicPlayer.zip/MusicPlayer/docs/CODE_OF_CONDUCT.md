In the Music-Player community, participants from all over the world come together to create Free Software for a free internet. This is made possible by the support, hard work and enthusiasm of thousands of people, including those who create and use Music-Player software.

Our code of conduct offers some guidance to ensure Music-Player participants can cooperate effectively in a positive and inspiring atmosphere, and to explain how together we can strengthen and support each other.

The Code of Conduct is shared by all contributors and users who engage with the Music-Player team and its community services. It presents a summary of the shared values and “common sense” thinking in our community.

Please, keep our CoC in mind when you contribute! That way, everyone can be a part of our community in a productive, positive, creative and fun way.