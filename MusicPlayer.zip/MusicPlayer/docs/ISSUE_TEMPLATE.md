### Actual behaviour
- Tell me what happens

### Expected behaviour
- Tell me what should happen
 
### Steps to reproduce
1. 
2. 
3. 


### Environment data
Android version:

Device model: 

Stock or customized system:

Music-Player app version:
